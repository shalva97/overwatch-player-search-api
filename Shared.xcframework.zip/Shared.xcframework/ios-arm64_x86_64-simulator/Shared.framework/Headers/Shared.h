#import <Foundation/NSArray.h>
#import <Foundation/NSDictionary.h>
#import <Foundation/NSError.h>
#import <Foundation/NSObject.h>
#import <Foundation/NSSet.h>
#import <Foundation/NSString.h>
#import <Foundation/NSValue.h>

@class SharedAssists, SharedAssistsDTO, SharedAssistsDTOCompanion, SharedAverage, SharedAverageDTO, SharedAverageDTOCompanion, SharedBest, SharedBestDTO, SharedBestDTOCompanion, SharedCareerHeroStats, SharedCareerHeroStatsDTO, SharedCareerHeroStatsDTOCompanion, SharedCombat, SharedCombatDTO, SharedCombatDTOCompanion, SharedCompetitiveStats, SharedCompetitiveStatsDTO, SharedCompetitiveStatsDTOCompanion, SharedGame, SharedGameDTO, SharedGameDTOCompanion, SharedKotlinArray<T>, SharedKotlinException, SharedKotlinIllegalStateException, SharedKotlinNothing, SharedKotlinRuntimeException, SharedKotlinThrowable, SharedKotlinx_serialization_coreSerialKind, SharedKotlinx_serialization_coreSerializersModule, SharedKotlinx_serialization_jsonJsonElement, SharedKotlinx_serialization_jsonJsonElementCompanion, SharedOverwatchPlayer, SharedOverwatchPlayerCompanion, SharedPlayerProfileStats, SharedPlayerProfileStatsDTO, SharedPlayerProfileStatsDTOCompanion, SharedQuickPlayStats, SharedQuickPlayStatsDTO, SharedQuickPlayStatsDTOCompanion, SharedRating, SharedRatingDTO, SharedRatingDTOCompanion, SharedTopHero, SharedTopHeroDTO, SharedTopHeroDTOCompanion;

@protocol SharedKotlinAnnotation, SharedKotlinIterator, SharedKotlinKAnnotatedElement, SharedKotlinKClass, SharedKotlinKClassifier, SharedKotlinKDeclarationContainer, SharedKotlinx_serialization_coreCompositeDecoder, SharedKotlinx_serialization_coreCompositeEncoder, SharedKotlinx_serialization_coreDecoder, SharedKotlinx_serialization_coreDeserializationStrategy, SharedKotlinx_serialization_coreEncoder, SharedKotlinx_serialization_coreKSerializer, SharedKotlinx_serialization_coreSerialDescriptor, SharedKotlinx_serialization_coreSerializationStrategy, SharedKotlinx_serialization_coreSerializersModuleCollector;

NS_ASSUME_NONNULL_BEGIN
#pragma clang diagnostic push
#pragma clang diagnostic ignored "-Wunknown-warning-option"
#pragma clang diagnostic ignored "-Wincompatible-property-type"
#pragma clang diagnostic ignored "-Wnullability"

#pragma push_macro("_Nullable_result")
#if !__has_feature(nullability_nullable_result)
#undef _Nullable_result
#define _Nullable_result _Nullable
#endif

__attribute__((swift_name("KotlinBase")))
@interface SharedBase : NSObject
- (instancetype)init __attribute__((unavailable));
+ (instancetype)new __attribute__((unavailable));
+ (void)initialize __attribute__((objc_requires_super));
@end

@interface SharedBase (SharedBaseCopying) <NSCopying>
@end

__attribute__((swift_name("KotlinMutableSet")))
@interface SharedMutableSet<ObjectType> : NSMutableSet<ObjectType>
@end

__attribute__((swift_name("KotlinMutableDictionary")))
@interface SharedMutableDictionary<KeyType, ObjectType> : NSMutableDictionary<KeyType, ObjectType>
@end

@interface NSError (NSErrorSharedKotlinException)
@property (readonly) id _Nullable kotlinException;
@end

__attribute__((swift_name("KotlinNumber")))
@interface SharedNumber : NSNumber
- (instancetype)initWithChar:(char)value __attribute__((unavailable));
- (instancetype)initWithUnsignedChar:(unsigned char)value __attribute__((unavailable));
- (instancetype)initWithShort:(short)value __attribute__((unavailable));
- (instancetype)initWithUnsignedShort:(unsigned short)value __attribute__((unavailable));
- (instancetype)initWithInt:(int)value __attribute__((unavailable));
- (instancetype)initWithUnsignedInt:(unsigned int)value __attribute__((unavailable));
- (instancetype)initWithLong:(long)value __attribute__((unavailable));
- (instancetype)initWithUnsignedLong:(unsigned long)value __attribute__((unavailable));
- (instancetype)initWithLongLong:(long long)value __attribute__((unavailable));
- (instancetype)initWithUnsignedLongLong:(unsigned long long)value __attribute__((unavailable));
- (instancetype)initWithFloat:(float)value __attribute__((unavailable));
- (instancetype)initWithDouble:(double)value __attribute__((unavailable));
- (instancetype)initWithBool:(BOOL)value __attribute__((unavailable));
- (instancetype)initWithInteger:(NSInteger)value __attribute__((unavailable));
- (instancetype)initWithUnsignedInteger:(NSUInteger)value __attribute__((unavailable));
+ (instancetype)numberWithChar:(char)value __attribute__((unavailable));
+ (instancetype)numberWithUnsignedChar:(unsigned char)value __attribute__((unavailable));
+ (instancetype)numberWithShort:(short)value __attribute__((unavailable));
+ (instancetype)numberWithUnsignedShort:(unsigned short)value __attribute__((unavailable));
+ (instancetype)numberWithInt:(int)value __attribute__((unavailable));
+ (instancetype)numberWithUnsignedInt:(unsigned int)value __attribute__((unavailable));
+ (instancetype)numberWithLong:(long)value __attribute__((unavailable));
+ (instancetype)numberWithUnsignedLong:(unsigned long)value __attribute__((unavailable));
+ (instancetype)numberWithLongLong:(long long)value __attribute__((unavailable));
+ (instancetype)numberWithUnsignedLongLong:(unsigned long long)value __attribute__((unavailable));
+ (instancetype)numberWithFloat:(float)value __attribute__((unavailable));
+ (instancetype)numberWithDouble:(double)value __attribute__((unavailable));
+ (instancetype)numberWithBool:(BOOL)value __attribute__((unavailable));
+ (instancetype)numberWithInteger:(NSInteger)value __attribute__((unavailable));
+ (instancetype)numberWithUnsignedInteger:(NSUInteger)value __attribute__((unavailable));
@end

__attribute__((swift_name("KotlinByte")))
@interface SharedByte : SharedNumber
- (instancetype)initWithChar:(char)value;
+ (instancetype)numberWithChar:(char)value;
@end

__attribute__((swift_name("KotlinUByte")))
@interface SharedUByte : SharedNumber
- (instancetype)initWithUnsignedChar:(unsigned char)value;
+ (instancetype)numberWithUnsignedChar:(unsigned char)value;
@end

__attribute__((swift_name("KotlinShort")))
@interface SharedShort : SharedNumber
- (instancetype)initWithShort:(short)value;
+ (instancetype)numberWithShort:(short)value;
@end

__attribute__((swift_name("KotlinUShort")))
@interface SharedUShort : SharedNumber
- (instancetype)initWithUnsignedShort:(unsigned short)value;
+ (instancetype)numberWithUnsignedShort:(unsigned short)value;
@end

__attribute__((swift_name("KotlinInt")))
@interface SharedInt : SharedNumber
- (instancetype)initWithInt:(int)value;
+ (instancetype)numberWithInt:(int)value;
@end

__attribute__((swift_name("KotlinUInt")))
@interface SharedUInt : SharedNumber
- (instancetype)initWithUnsignedInt:(unsigned int)value;
+ (instancetype)numberWithUnsignedInt:(unsigned int)value;
@end

__attribute__((swift_name("KotlinLong")))
@interface SharedLong : SharedNumber
- (instancetype)initWithLongLong:(long long)value;
+ (instancetype)numberWithLongLong:(long long)value;
@end

__attribute__((swift_name("KotlinULong")))
@interface SharedULong : SharedNumber
- (instancetype)initWithUnsignedLongLong:(unsigned long long)value;
+ (instancetype)numberWithUnsignedLongLong:(unsigned long long)value;
@end

__attribute__((swift_name("KotlinFloat")))
@interface SharedFloat : SharedNumber
- (instancetype)initWithFloat:(float)value;
+ (instancetype)numberWithFloat:(float)value;
@end

__attribute__((swift_name("KotlinDouble")))
@interface SharedDouble : SharedNumber
- (instancetype)initWithDouble:(double)value;
+ (instancetype)numberWithDouble:(double)value;
@end

__attribute__((swift_name("KotlinBoolean")))
@interface SharedBoolean : SharedNumber
- (instancetype)initWithBool:(BOOL)value;
+ (instancetype)numberWithBool:(BOOL)value;
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("PlayerSearch")))
@interface SharedPlayerSearch : SharedBase
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (void)close __attribute__((swift_name("close()")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)getPlayerProfileForConsolePlayerTag:(NSString *)playerTag completionHandler:(void (^)(SharedPlayerProfileStats * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("getPlayerProfileForConsole(playerTag:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)getPlayerProfileForPCPlayerTag:(NSString *)playerTag completionHandler:(void (^)(SharedPlayerProfileStats * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("getPlayerProfileForPC(playerTag:completionHandler:)")));

/**
 * @note This method converts instances of CancellationException to errors.
 * Other uncaught Kotlin exceptions are fatal.
*/
- (void)searchForPlayerName:(NSString *)name language:(NSString *)language completionHandler:(void (^)(NSArray<SharedOverwatchPlayer *> * _Nullable, NSError * _Nullable))completionHandler __attribute__((swift_name("searchForPlayer(name:language:completionHandler:)")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("AssistsDTO")))
@interface SharedAssistsDTO : SharedBase
- (instancetype)initWithAssists:(SharedInt * _Nullable)assists defensiveAssists:(SharedInt * _Nullable)defensiveAssists healingDone:(SharedInt * _Nullable)healingDone offensiveAssists:(SharedInt * _Nullable)offensiveAssists reconAssists:(SharedInt * _Nullable)reconAssists __attribute__((swift_name("init(assists:defensiveAssists:healingDone:offensiveAssists:reconAssists:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) SharedAssistsDTOCompanion *companion __attribute__((swift_name("companion")));
- (SharedAssistsDTO *)doCopyAssists:(SharedInt * _Nullable)assists defensiveAssists:(SharedInt * _Nullable)defensiveAssists healingDone:(SharedInt * _Nullable)healingDone offensiveAssists:(SharedInt * _Nullable)offensiveAssists reconAssists:(SharedInt * _Nullable)reconAssists __attribute__((swift_name("doCopy(assists:defensiveAssists:healingDone:offensiveAssists:reconAssists:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) SharedInt * _Nullable assists __attribute__((swift_name("assists")));
@property (readonly) SharedInt * _Nullable defensiveAssists __attribute__((swift_name("defensiveAssists")));
@property (readonly) SharedInt * _Nullable healingDone __attribute__((swift_name("healingDone")));
@property (readonly) SharedInt * _Nullable offensiveAssists __attribute__((swift_name("offensiveAssists")));
@property (readonly) SharedInt * _Nullable reconAssists __attribute__((swift_name("reconAssists")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("AssistsDTO.Companion")))
@interface SharedAssistsDTOCompanion : SharedBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SharedAssistsDTOCompanion *shared __attribute__((swift_name("shared")));
- (id<SharedKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("AverageDTO")))
@interface SharedAverageDTO : SharedBase
- (instancetype)initWithAssistsAvgPer10Min:(SharedFloat * _Nullable)assistsAvgPer10Min deathsAvgPer10Min:(SharedFloat * _Nullable)deathsAvgPer10Min eliminationsAvgPer10Min:(SharedFloat * _Nullable)eliminationsAvgPer10Min finalBlowsAvgPer10Min:(SharedFloat * _Nullable)finalBlowsAvgPer10Min healingDoneAvgPer10Min:(SharedFloat * _Nullable)healingDoneAvgPer10Min heroDamageDoneAvgPer10Min:(SharedFloat * _Nullable)heroDamageDoneAvgPer10Min objectiveContestTimeAvgPer10Min:(NSString * _Nullable)objectiveContestTimeAvgPer10Min objectiveKillsAvgPer10Min:(SharedFloat * _Nullable)objectiveKillsAvgPer10Min objectiveTimeAvgPer10Min:(NSString * _Nullable)objectiveTimeAvgPer10Min soloKillsAvgPer10Min:(SharedFloat * _Nullable)soloKillsAvgPer10Min timeSpentOnFireAvgPer10Min:(NSString * _Nullable)timeSpentOnFireAvgPer10Min __attribute__((swift_name("init(assistsAvgPer10Min:deathsAvgPer10Min:eliminationsAvgPer10Min:finalBlowsAvgPer10Min:healingDoneAvgPer10Min:heroDamageDoneAvgPer10Min:objectiveContestTimeAvgPer10Min:objectiveKillsAvgPer10Min:objectiveTimeAvgPer10Min:soloKillsAvgPer10Min:timeSpentOnFireAvgPer10Min:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) SharedAverageDTOCompanion *companion __attribute__((swift_name("companion")));
- (SharedAverageDTO *)doCopyAssistsAvgPer10Min:(SharedFloat * _Nullable)assistsAvgPer10Min deathsAvgPer10Min:(SharedFloat * _Nullable)deathsAvgPer10Min eliminationsAvgPer10Min:(SharedFloat * _Nullable)eliminationsAvgPer10Min finalBlowsAvgPer10Min:(SharedFloat * _Nullable)finalBlowsAvgPer10Min healingDoneAvgPer10Min:(SharedFloat * _Nullable)healingDoneAvgPer10Min heroDamageDoneAvgPer10Min:(SharedFloat * _Nullable)heroDamageDoneAvgPer10Min objectiveContestTimeAvgPer10Min:(NSString * _Nullable)objectiveContestTimeAvgPer10Min objectiveKillsAvgPer10Min:(SharedFloat * _Nullable)objectiveKillsAvgPer10Min objectiveTimeAvgPer10Min:(NSString * _Nullable)objectiveTimeAvgPer10Min soloKillsAvgPer10Min:(SharedFloat * _Nullable)soloKillsAvgPer10Min timeSpentOnFireAvgPer10Min:(NSString * _Nullable)timeSpentOnFireAvgPer10Min __attribute__((swift_name("doCopy(assistsAvgPer10Min:deathsAvgPer10Min:eliminationsAvgPer10Min:finalBlowsAvgPer10Min:healingDoneAvgPer10Min:heroDamageDoneAvgPer10Min:objectiveContestTimeAvgPer10Min:objectiveKillsAvgPer10Min:objectiveTimeAvgPer10Min:soloKillsAvgPer10Min:timeSpentOnFireAvgPer10Min:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) SharedFloat * _Nullable assistsAvgPer10Min __attribute__((swift_name("assistsAvgPer10Min")));
@property (readonly) SharedFloat * _Nullable deathsAvgPer10Min __attribute__((swift_name("deathsAvgPer10Min")));
@property (readonly) SharedFloat * _Nullable eliminationsAvgPer10Min __attribute__((swift_name("eliminationsAvgPer10Min")));
@property (readonly) SharedFloat * _Nullable finalBlowsAvgPer10Min __attribute__((swift_name("finalBlowsAvgPer10Min")));
@property (readonly) SharedFloat * _Nullable healingDoneAvgPer10Min __attribute__((swift_name("healingDoneAvgPer10Min")));
@property (readonly) SharedFloat * _Nullable heroDamageDoneAvgPer10Min __attribute__((swift_name("heroDamageDoneAvgPer10Min")));
@property (readonly) NSString * _Nullable objectiveContestTimeAvgPer10Min __attribute__((swift_name("objectiveContestTimeAvgPer10Min")));
@property (readonly) SharedFloat * _Nullable objectiveKillsAvgPer10Min __attribute__((swift_name("objectiveKillsAvgPer10Min")));
@property (readonly) NSString * _Nullable objectiveTimeAvgPer10Min __attribute__((swift_name("objectiveTimeAvgPer10Min")));
@property (readonly) SharedFloat * _Nullable soloKillsAvgPer10Min __attribute__((swift_name("soloKillsAvgPer10Min")));
@property (readonly) NSString * _Nullable timeSpentOnFireAvgPer10Min __attribute__((swift_name("timeSpentOnFireAvgPer10Min")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("AverageDTO.Companion")))
@interface SharedAverageDTOCompanion : SharedBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SharedAverageDTOCompanion *shared __attribute__((swift_name("shared")));
- (id<SharedKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("BestDTO")))
@interface SharedBestDTO : SharedBase
- (instancetype)initWithAllDamageDoneMostInGame:(SharedInt * _Nullable)allDamageDoneMostInGame assistsMostInGame:(SharedInt * _Nullable)assistsMostInGame barrierDamageDoneMostInGame:(SharedInt * _Nullable)barrierDamageDoneMostInGame defensiveAssistsMostInGame:(SharedInt * _Nullable)defensiveAssistsMostInGame eliminationsMostInGame:(SharedInt * _Nullable)eliminationsMostInGame environmentalKillsMostInGame:(SharedInt * _Nullable)environmentalKillsMostInGame finalBlowsMostInGame:(SharedInt * _Nullable)finalBlowsMostInGame healingDoneMostInGame:(SharedInt * _Nullable)healingDoneMostInGame heroDamageDoneMostInGame:(SharedInt * _Nullable)heroDamageDoneMostInGame killsStreakBest:(SharedInt * _Nullable)killsStreakBest meleeFinalBlowsMostInGame:(SharedInt * _Nullable)meleeFinalBlowsMostInGame multikillsBest:(SharedInt * _Nullable)multikillsBest objectiveContestTimeMostInGame:(NSString * _Nullable)objectiveContestTimeMostInGame objectiveKillsMostInGame:(SharedInt * _Nullable)objectiveKillsMostInGame objectiveTimeMostInGame:(NSString * _Nullable)objectiveTimeMostInGame offensiveAssistsMostInGame:(SharedInt * _Nullable)offensiveAssistsMostInGame reconAssistsMostInGame:(SharedInt * _Nullable)reconAssistsMostInGame soloKillsMostInGame:(SharedInt * _Nullable)soloKillsMostInGame timeSpentOnFireMostInGame:(NSString * _Nullable)timeSpentOnFireMostInGame __attribute__((swift_name("init(allDamageDoneMostInGame:assistsMostInGame:barrierDamageDoneMostInGame:defensiveAssistsMostInGame:eliminationsMostInGame:environmentalKillsMostInGame:finalBlowsMostInGame:healingDoneMostInGame:heroDamageDoneMostInGame:killsStreakBest:meleeFinalBlowsMostInGame:multikillsBest:objectiveContestTimeMostInGame:objectiveKillsMostInGame:objectiveTimeMostInGame:offensiveAssistsMostInGame:reconAssistsMostInGame:soloKillsMostInGame:timeSpentOnFireMostInGame:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) SharedBestDTOCompanion *companion __attribute__((swift_name("companion")));
- (SharedBestDTO *)doCopyAllDamageDoneMostInGame:(SharedInt * _Nullable)allDamageDoneMostInGame assistsMostInGame:(SharedInt * _Nullable)assistsMostInGame barrierDamageDoneMostInGame:(SharedInt * _Nullable)barrierDamageDoneMostInGame defensiveAssistsMostInGame:(SharedInt * _Nullable)defensiveAssistsMostInGame eliminationsMostInGame:(SharedInt * _Nullable)eliminationsMostInGame environmentalKillsMostInGame:(SharedInt * _Nullable)environmentalKillsMostInGame finalBlowsMostInGame:(SharedInt * _Nullable)finalBlowsMostInGame healingDoneMostInGame:(SharedInt * _Nullable)healingDoneMostInGame heroDamageDoneMostInGame:(SharedInt * _Nullable)heroDamageDoneMostInGame killsStreakBest:(SharedInt * _Nullable)killsStreakBest meleeFinalBlowsMostInGame:(SharedInt * _Nullable)meleeFinalBlowsMostInGame multikillsBest:(SharedInt * _Nullable)multikillsBest objectiveContestTimeMostInGame:(NSString * _Nullable)objectiveContestTimeMostInGame objectiveKillsMostInGame:(SharedInt * _Nullable)objectiveKillsMostInGame objectiveTimeMostInGame:(NSString * _Nullable)objectiveTimeMostInGame offensiveAssistsMostInGame:(SharedInt * _Nullable)offensiveAssistsMostInGame reconAssistsMostInGame:(SharedInt * _Nullable)reconAssistsMostInGame soloKillsMostInGame:(SharedInt * _Nullable)soloKillsMostInGame timeSpentOnFireMostInGame:(NSString * _Nullable)timeSpentOnFireMostInGame __attribute__((swift_name("doCopy(allDamageDoneMostInGame:assistsMostInGame:barrierDamageDoneMostInGame:defensiveAssistsMostInGame:eliminationsMostInGame:environmentalKillsMostInGame:finalBlowsMostInGame:healingDoneMostInGame:heroDamageDoneMostInGame:killsStreakBest:meleeFinalBlowsMostInGame:multikillsBest:objectiveContestTimeMostInGame:objectiveKillsMostInGame:objectiveTimeMostInGame:offensiveAssistsMostInGame:reconAssistsMostInGame:soloKillsMostInGame:timeSpentOnFireMostInGame:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) SharedInt * _Nullable allDamageDoneMostInGame __attribute__((swift_name("allDamageDoneMostInGame")));
@property (readonly) SharedInt * _Nullable assistsMostInGame __attribute__((swift_name("assistsMostInGame")));
@property (readonly) SharedInt * _Nullable barrierDamageDoneMostInGame __attribute__((swift_name("barrierDamageDoneMostInGame")));
@property (readonly) SharedInt * _Nullable defensiveAssistsMostInGame __attribute__((swift_name("defensiveAssistsMostInGame")));
@property (readonly) SharedInt * _Nullable eliminationsMostInGame __attribute__((swift_name("eliminationsMostInGame")));
@property (readonly) SharedInt * _Nullable environmentalKillsMostInGame __attribute__((swift_name("environmentalKillsMostInGame")));
@property (readonly) SharedInt * _Nullable finalBlowsMostInGame __attribute__((swift_name("finalBlowsMostInGame")));
@property (readonly) SharedInt * _Nullable healingDoneMostInGame __attribute__((swift_name("healingDoneMostInGame")));
@property (readonly) SharedInt * _Nullable heroDamageDoneMostInGame __attribute__((swift_name("heroDamageDoneMostInGame")));
@property (readonly) SharedInt * _Nullable killsStreakBest __attribute__((swift_name("killsStreakBest")));
@property (readonly) SharedInt * _Nullable meleeFinalBlowsMostInGame __attribute__((swift_name("meleeFinalBlowsMostInGame")));
@property (readonly) SharedInt * _Nullable multikillsBest __attribute__((swift_name("multikillsBest")));
@property (readonly) NSString * _Nullable objectiveContestTimeMostInGame __attribute__((swift_name("objectiveContestTimeMostInGame")));
@property (readonly) SharedInt * _Nullable objectiveKillsMostInGame __attribute__((swift_name("objectiveKillsMostInGame")));
@property (readonly) NSString * _Nullable objectiveTimeMostInGame __attribute__((swift_name("objectiveTimeMostInGame")));
@property (readonly) SharedInt * _Nullable offensiveAssistsMostInGame __attribute__((swift_name("offensiveAssistsMostInGame")));
@property (readonly) SharedInt * _Nullable reconAssistsMostInGame __attribute__((swift_name("reconAssistsMostInGame")));
@property (readonly) SharedInt * _Nullable soloKillsMostInGame __attribute__((swift_name("soloKillsMostInGame")));
@property (readonly) NSString * _Nullable timeSpentOnFireMostInGame __attribute__((swift_name("timeSpentOnFireMostInGame")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("BestDTO.Companion")))
@interface SharedBestDTOCompanion : SharedBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SharedBestDTOCompanion *shared __attribute__((swift_name("shared")));
- (id<SharedKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("CareerHeroStatsDTO")))
@interface SharedCareerHeroStatsDTO : SharedBase
- (instancetype)initWithAssists:(SharedAssistsDTO * _Nullable)assists average:(SharedAverageDTO * _Nullable)average best:(SharedBestDTO * _Nullable)best combat:(SharedCombatDTO * _Nullable)combat heroSpecific:(SharedKotlinx_serialization_jsonJsonElement * _Nullable)heroSpecific game:(SharedGameDTO *)game matchAwards:(SharedKotlinx_serialization_jsonJsonElement * _Nullable)matchAwards __attribute__((swift_name("init(assists:average:best:combat:heroSpecific:game:matchAwards:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) SharedCareerHeroStatsDTOCompanion *companion __attribute__((swift_name("companion")));
- (SharedCareerHeroStatsDTO *)doCopyAssists:(SharedAssistsDTO * _Nullable)assists average:(SharedAverageDTO * _Nullable)average best:(SharedBestDTO * _Nullable)best combat:(SharedCombatDTO * _Nullable)combat heroSpecific:(SharedKotlinx_serialization_jsonJsonElement * _Nullable)heroSpecific game:(SharedGameDTO *)game matchAwards:(SharedKotlinx_serialization_jsonJsonElement * _Nullable)matchAwards __attribute__((swift_name("doCopy(assists:average:best:combat:heroSpecific:game:matchAwards:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) SharedAssistsDTO * _Nullable assists __attribute__((swift_name("assists")));
@property (readonly) SharedAverageDTO * _Nullable average __attribute__((swift_name("average")));
@property (readonly) SharedBestDTO * _Nullable best __attribute__((swift_name("best")));
@property (readonly) SharedCombatDTO * _Nullable combat __attribute__((swift_name("combat")));
@property (readonly) SharedGameDTO *game __attribute__((swift_name("game")));
@property (readonly) SharedKotlinx_serialization_jsonJsonElement * _Nullable heroSpecific __attribute__((swift_name("heroSpecific")));
@property (readonly) SharedKotlinx_serialization_jsonJsonElement * _Nullable matchAwards __attribute__((swift_name("matchAwards")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("CareerHeroStatsDTO.Companion")))
@interface SharedCareerHeroStatsDTOCompanion : SharedBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SharedCareerHeroStatsDTOCompanion *shared __attribute__((swift_name("shared")));
- (id<SharedKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("CombatDTO")))
@interface SharedCombatDTO : SharedBase
- (instancetype)initWithDamageDone:(SharedInt * _Nullable)damageDone deaths:(SharedInt * _Nullable)deaths eliminations:(SharedInt * _Nullable)eliminations environmentalKills:(SharedInt * _Nullable)environmentalKills finalBlows:(SharedInt * _Nullable)finalBlows heroDamageDone:(SharedInt * _Nullable)heroDamageDone meleeFinalBlows:(SharedInt * _Nullable)meleeFinalBlows multikills:(SharedInt * _Nullable)multikills objectiveContestTime:(NSString * _Nullable)objectiveContestTime objectiveKills:(SharedInt * _Nullable)objectiveKills objectiveTime:(NSString * _Nullable)objectiveTime soloKills:(SharedInt * _Nullable)soloKills timeSpentOnFire:(NSString * _Nullable)timeSpentOnFire __attribute__((swift_name("init(damageDone:deaths:eliminations:environmentalKills:finalBlows:heroDamageDone:meleeFinalBlows:multikills:objectiveContestTime:objectiveKills:objectiveTime:soloKills:timeSpentOnFire:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) SharedCombatDTOCompanion *companion __attribute__((swift_name("companion")));
- (SharedCombatDTO *)doCopyDamageDone:(SharedInt * _Nullable)damageDone deaths:(SharedInt * _Nullable)deaths eliminations:(SharedInt * _Nullable)eliminations environmentalKills:(SharedInt * _Nullable)environmentalKills finalBlows:(SharedInt * _Nullable)finalBlows heroDamageDone:(SharedInt * _Nullable)heroDamageDone meleeFinalBlows:(SharedInt * _Nullable)meleeFinalBlows multikills:(SharedInt * _Nullable)multikills objectiveContestTime:(NSString * _Nullable)objectiveContestTime objectiveKills:(SharedInt * _Nullable)objectiveKills objectiveTime:(NSString * _Nullable)objectiveTime soloKills:(SharedInt * _Nullable)soloKills timeSpentOnFire:(NSString * _Nullable)timeSpentOnFire __attribute__((swift_name("doCopy(damageDone:deaths:eliminations:environmentalKills:finalBlows:heroDamageDone:meleeFinalBlows:multikills:objectiveContestTime:objectiveKills:objectiveTime:soloKills:timeSpentOnFire:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) SharedInt * _Nullable damageDone __attribute__((swift_name("damageDone")));
@property (readonly) SharedInt * _Nullable deaths __attribute__((swift_name("deaths")));
@property (readonly) SharedInt * _Nullable eliminations __attribute__((swift_name("eliminations")));
@property (readonly) SharedInt * _Nullable environmentalKills __attribute__((swift_name("environmentalKills")));
@property (readonly) SharedInt * _Nullable finalBlows __attribute__((swift_name("finalBlows")));
@property (readonly) SharedInt * _Nullable heroDamageDone __attribute__((swift_name("heroDamageDone")));
@property (readonly) SharedInt * _Nullable meleeFinalBlows __attribute__((swift_name("meleeFinalBlows")));
@property (readonly) SharedInt * _Nullable multikills __attribute__((swift_name("multikills")));
@property (readonly) NSString * _Nullable objectiveContestTime __attribute__((swift_name("objectiveContestTime")));
@property (readonly) SharedInt * _Nullable objectiveKills __attribute__((swift_name("objectiveKills")));
@property (readonly) NSString * _Nullable objectiveTime __attribute__((swift_name("objectiveTime")));
@property (readonly) SharedInt * _Nullable soloKills __attribute__((swift_name("soloKills")));
@property (readonly) NSString * _Nullable timeSpentOnFire __attribute__((swift_name("timeSpentOnFire")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("CombatDTO.Companion")))
@interface SharedCombatDTOCompanion : SharedBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SharedCombatDTOCompanion *shared __attribute__((swift_name("shared")));
- (id<SharedKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("CompetitiveStatsDTO")))
@interface SharedCompetitiveStatsDTO : SharedBase
- (instancetype)initWithSeason:(int32_t)season topHeroes:(NSDictionary<NSString *, SharedTopHeroDTO *> *)topHeroes careerStats:(NSDictionary<NSString *, SharedCareerHeroStatsDTO *> *)careerStats __attribute__((swift_name("init(season:topHeroes:careerStats:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) SharedCompetitiveStatsDTOCompanion *companion __attribute__((swift_name("companion")));
- (SharedCompetitiveStatsDTO *)doCopySeason:(int32_t)season topHeroes:(NSDictionary<NSString *, SharedTopHeroDTO *> *)topHeroes careerStats:(NSDictionary<NSString *, SharedCareerHeroStatsDTO *> *)careerStats __attribute__((swift_name("doCopy(season:topHeroes:careerStats:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSDictionary<NSString *, SharedCareerHeroStatsDTO *> *careerStats __attribute__((swift_name("careerStats")));
@property (readonly) int32_t season __attribute__((swift_name("season")));
@property (readonly) NSDictionary<NSString *, SharedTopHeroDTO *> *topHeroes __attribute__((swift_name("topHeroes")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("CompetitiveStatsDTO.Companion")))
@interface SharedCompetitiveStatsDTOCompanion : SharedBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SharedCompetitiveStatsDTOCompanion *shared __attribute__((swift_name("shared")));
- (id<SharedKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("GameDTO")))
@interface SharedGameDTO : SharedBase
- (instancetype)initWithGamesLost:(int32_t)gamesLost gamesPlayed:(SharedInt * _Nullable)gamesPlayed gamesWon:(SharedInt * _Nullable)gamesWon heroWins:(SharedInt * _Nullable)heroWins timePlayed:(NSString *)timePlayed __attribute__((swift_name("init(gamesLost:gamesPlayed:gamesWon:heroWins:timePlayed:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) SharedGameDTOCompanion *companion __attribute__((swift_name("companion")));
- (SharedGameDTO *)doCopyGamesLost:(int32_t)gamesLost gamesPlayed:(SharedInt * _Nullable)gamesPlayed gamesWon:(SharedInt * _Nullable)gamesWon heroWins:(SharedInt * _Nullable)heroWins timePlayed:(NSString *)timePlayed __attribute__((swift_name("doCopy(gamesLost:gamesPlayed:gamesWon:heroWins:timePlayed:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) int32_t gamesLost __attribute__((swift_name("gamesLost")));
@property (readonly) SharedInt * _Nullable gamesPlayed __attribute__((swift_name("gamesPlayed")));
@property (readonly) SharedInt * _Nullable gamesWon __attribute__((swift_name("gamesWon")));
@property (readonly) SharedInt * _Nullable heroWins __attribute__((swift_name("heroWins")));
@property (readonly) NSString *timePlayed __attribute__((swift_name("timePlayed")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("GameDTO.Companion")))
@interface SharedGameDTOCompanion : SharedBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SharedGameDTOCompanion *shared __attribute__((swift_name("shared")));
- (id<SharedKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("PlayerProfileStatsDTO")))
@interface SharedPlayerProfileStatsDTO : SharedBase
- (instancetype)initWithIcon:(NSString *)icon name:(NSString *)name endorsement:(int32_t)endorsement endorsementIcon:(NSString *)endorsementIcon title:(NSString *)title ratings:(NSArray<SharedRatingDTO *> * _Nullable)ratings gamesWon:(int32_t)gamesWon gamesLost:(int32_t)gamesLost gamesPlayed:(int32_t)gamesPlayed private:(BOOL)private_ quickPlayStats:(SharedQuickPlayStatsDTO *)quickPlayStats competitiveStats:(SharedCompetitiveStatsDTO *)competitiveStats __attribute__((swift_name("init(icon:name:endorsement:endorsementIcon:title:ratings:gamesWon:gamesLost:gamesPlayed:private:quickPlayStats:competitiveStats:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) SharedPlayerProfileStatsDTOCompanion *companion __attribute__((swift_name("companion")));
- (SharedPlayerProfileStatsDTO *)doCopyIcon:(NSString *)icon name:(NSString *)name endorsement:(int32_t)endorsement endorsementIcon:(NSString *)endorsementIcon title:(NSString *)title ratings:(NSArray<SharedRatingDTO *> * _Nullable)ratings gamesWon:(int32_t)gamesWon gamesLost:(int32_t)gamesLost gamesPlayed:(int32_t)gamesPlayed private:(BOOL)private_ quickPlayStats:(SharedQuickPlayStatsDTO *)quickPlayStats competitiveStats:(SharedCompetitiveStatsDTO *)competitiveStats __attribute__((swift_name("doCopy(icon:name:endorsement:endorsementIcon:title:ratings:gamesWon:gamesLost:gamesPlayed:private:quickPlayStats:competitiveStats:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) SharedCompetitiveStatsDTO *competitiveStats __attribute__((swift_name("competitiveStats")));
@property (readonly) int32_t endorsement __attribute__((swift_name("endorsement")));
@property (readonly) NSString *endorsementIcon __attribute__((swift_name("endorsementIcon")));
@property (readonly) int32_t gamesLost __attribute__((swift_name("gamesLost")));
@property (readonly) int32_t gamesPlayed __attribute__((swift_name("gamesPlayed")));
@property (readonly) int32_t gamesWon __attribute__((swift_name("gamesWon")));
@property (readonly) NSString *icon __attribute__((swift_name("icon")));
@property (readonly) NSString *name __attribute__((swift_name("name")));
@property (readonly, getter=private) BOOL private_ __attribute__((swift_name("private_")));
@property (readonly) SharedQuickPlayStatsDTO *quickPlayStats __attribute__((swift_name("quickPlayStats")));
@property (readonly) NSArray<SharedRatingDTO *> * _Nullable ratings __attribute__((swift_name("ratings")));
@property (readonly) NSString *title __attribute__((swift_name("title")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("PlayerProfileStatsDTO.Companion")))
@interface SharedPlayerProfileStatsDTOCompanion : SharedBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SharedPlayerProfileStatsDTOCompanion *shared __attribute__((swift_name("shared")));
- (id<SharedKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("QuickPlayStatsDTO")))
@interface SharedQuickPlayStatsDTO : SharedBase
- (instancetype)initWithTopHeroes:(NSDictionary<NSString *, SharedTopHeroDTO *> *)topHeroes careerStats:(NSDictionary<NSString *, SharedCareerHeroStatsDTO *> *)careerStats __attribute__((swift_name("init(topHeroes:careerStats:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) SharedQuickPlayStatsDTOCompanion *companion __attribute__((swift_name("companion")));
- (SharedQuickPlayStatsDTO *)doCopyTopHeroes:(NSDictionary<NSString *, SharedTopHeroDTO *> *)topHeroes careerStats:(NSDictionary<NSString *, SharedCareerHeroStatsDTO *> *)careerStats __attribute__((swift_name("doCopy(topHeroes:careerStats:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSDictionary<NSString *, SharedCareerHeroStatsDTO *> *careerStats __attribute__((swift_name("careerStats")));
@property (readonly) NSDictionary<NSString *, SharedTopHeroDTO *> *topHeroes __attribute__((swift_name("topHeroes")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("QuickPlayStatsDTO.Companion")))
@interface SharedQuickPlayStatsDTOCompanion : SharedBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SharedQuickPlayStatsDTOCompanion *shared __attribute__((swift_name("shared")));
- (id<SharedKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("RatingDTO")))
@interface SharedRatingDTO : SharedBase
- (instancetype)initWithGroup:(NSString *)group tier:(int32_t)tier role:(NSString *)role roleIcon:(NSString *)roleIcon rankIcon:(NSString *)rankIcon tierIcon:(NSString *)tierIcon __attribute__((swift_name("init(group:tier:role:roleIcon:rankIcon:tierIcon:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) SharedRatingDTOCompanion *companion __attribute__((swift_name("companion")));
- (SharedRatingDTO *)doCopyGroup:(NSString *)group tier:(int32_t)tier role:(NSString *)role roleIcon:(NSString *)roleIcon rankIcon:(NSString *)rankIcon tierIcon:(NSString *)tierIcon __attribute__((swift_name("doCopy(group:tier:role:roleIcon:rankIcon:tierIcon:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *group __attribute__((swift_name("group")));
@property (readonly) NSString *rankIcon __attribute__((swift_name("rankIcon")));
@property (readonly) NSString *role __attribute__((swift_name("role")));
@property (readonly) NSString *roleIcon __attribute__((swift_name("roleIcon")));
@property (readonly) int32_t tier __attribute__((swift_name("tier")));
@property (readonly) NSString *tierIcon __attribute__((swift_name("tierIcon")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("RatingDTO.Companion")))
@interface SharedRatingDTOCompanion : SharedBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SharedRatingDTOCompanion *shared __attribute__((swift_name("shared")));
- (id<SharedKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("TopHeroDTO")))
@interface SharedTopHeroDTO : SharedBase
- (instancetype)initWithTimePlayed:(NSString *)timePlayed gamesWon:(int32_t)gamesWon weaponAccuracy:(float)weaponAccuracy criticalHitAccuracy:(float)criticalHitAccuracy eliminationsPerLife:(float)eliminationsPerLife multiKillBest:(int32_t)multiKillBest objectiveKills:(int32_t)objectiveKills __attribute__((swift_name("init(timePlayed:gamesWon:weaponAccuracy:criticalHitAccuracy:eliminationsPerLife:multiKillBest:objectiveKills:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) SharedTopHeroDTOCompanion *companion __attribute__((swift_name("companion")));
- (SharedTopHeroDTO *)doCopyTimePlayed:(NSString *)timePlayed gamesWon:(int32_t)gamesWon weaponAccuracy:(float)weaponAccuracy criticalHitAccuracy:(float)criticalHitAccuracy eliminationsPerLife:(float)eliminationsPerLife multiKillBest:(int32_t)multiKillBest objectiveKills:(int32_t)objectiveKills __attribute__((swift_name("doCopy(timePlayed:gamesWon:weaponAccuracy:criticalHitAccuracy:eliminationsPerLife:multiKillBest:objectiveKills:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) float criticalHitAccuracy __attribute__((swift_name("criticalHitAccuracy")));
@property (readonly) float eliminationsPerLife __attribute__((swift_name("eliminationsPerLife")));
@property (readonly) int32_t gamesWon __attribute__((swift_name("gamesWon")));
@property (readonly) int32_t multiKillBest __attribute__((swift_name("multiKillBest")));
@property (readonly) int32_t objectiveKills __attribute__((swift_name("objectiveKills")));
@property (readonly) NSString *timePlayed __attribute__((swift_name("timePlayed")));
@property (readonly) int64_t timePlayedDuration __attribute__((swift_name("timePlayedDuration")));
@property (readonly) float weaponAccuracy __attribute__((swift_name("weaponAccuracy")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("TopHeroDTO.Companion")))
@interface SharedTopHeroDTOCompanion : SharedBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SharedTopHeroDTOCompanion *shared __attribute__((swift_name("shared")));
- (id<SharedKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Assists")))
@interface SharedAssists : SharedBase
- (instancetype)initWithAssists:(SharedInt * _Nullable)assists defensiveAssists:(SharedInt * _Nullable)defensiveAssists healingDone:(SharedInt * _Nullable)healingDone offensiveAssists:(SharedInt * _Nullable)offensiveAssists reconAssists:(SharedInt * _Nullable)reconAssists __attribute__((swift_name("init(assists:defensiveAssists:healingDone:offensiveAssists:reconAssists:)"))) __attribute__((objc_designated_initializer));
- (SharedAssists *)doCopyAssists:(SharedInt * _Nullable)assists defensiveAssists:(SharedInt * _Nullable)defensiveAssists healingDone:(SharedInt * _Nullable)healingDone offensiveAssists:(SharedInt * _Nullable)offensiveAssists reconAssists:(SharedInt * _Nullable)reconAssists __attribute__((swift_name("doCopy(assists:defensiveAssists:healingDone:offensiveAssists:reconAssists:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) SharedInt * _Nullable assists __attribute__((swift_name("assists")));
@property (readonly) SharedInt * _Nullable defensiveAssists __attribute__((swift_name("defensiveAssists")));
@property (readonly) SharedInt * _Nullable healingDone __attribute__((swift_name("healingDone")));
@property (readonly) SharedInt * _Nullable offensiveAssists __attribute__((swift_name("offensiveAssists")));
@property (readonly) SharedInt * _Nullable reconAssists __attribute__((swift_name("reconAssists")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Average")))
@interface SharedAverage : SharedBase
- (instancetype)initWithAssistsAvgPer10Min:(SharedFloat * _Nullable)assistsAvgPer10Min deathsAvgPer10Min:(SharedFloat * _Nullable)deathsAvgPer10Min eliminationsAvgPer10Min:(SharedFloat * _Nullable)eliminationsAvgPer10Min finalBlowsAvgPer10Min:(SharedFloat * _Nullable)finalBlowsAvgPer10Min healingDoneAvgPer10Min:(SharedFloat * _Nullable)healingDoneAvgPer10Min heroDamageDoneAvgPer10Min:(SharedFloat * _Nullable)heroDamageDoneAvgPer10Min objectiveContestTimeAvgPer10Min:(NSString * _Nullable)objectiveContestTimeAvgPer10Min objectiveKillsAvgPer10Min:(SharedFloat * _Nullable)objectiveKillsAvgPer10Min objectiveTimeAvgPer10Min:(NSString * _Nullable)objectiveTimeAvgPer10Min soloKillsAvgPer10Min:(SharedFloat * _Nullable)soloKillsAvgPer10Min timeSpentOnFireAvgPer10Min:(NSString * _Nullable)timeSpentOnFireAvgPer10Min __attribute__((swift_name("init(assistsAvgPer10Min:deathsAvgPer10Min:eliminationsAvgPer10Min:finalBlowsAvgPer10Min:healingDoneAvgPer10Min:heroDamageDoneAvgPer10Min:objectiveContestTimeAvgPer10Min:objectiveKillsAvgPer10Min:objectiveTimeAvgPer10Min:soloKillsAvgPer10Min:timeSpentOnFireAvgPer10Min:)"))) __attribute__((objc_designated_initializer));
- (SharedAverage *)doCopyAssistsAvgPer10Min:(SharedFloat * _Nullable)assistsAvgPer10Min deathsAvgPer10Min:(SharedFloat * _Nullable)deathsAvgPer10Min eliminationsAvgPer10Min:(SharedFloat * _Nullable)eliminationsAvgPer10Min finalBlowsAvgPer10Min:(SharedFloat * _Nullable)finalBlowsAvgPer10Min healingDoneAvgPer10Min:(SharedFloat * _Nullable)healingDoneAvgPer10Min heroDamageDoneAvgPer10Min:(SharedFloat * _Nullable)heroDamageDoneAvgPer10Min objectiveContestTimeAvgPer10Min:(NSString * _Nullable)objectiveContestTimeAvgPer10Min objectiveKillsAvgPer10Min:(SharedFloat * _Nullable)objectiveKillsAvgPer10Min objectiveTimeAvgPer10Min:(NSString * _Nullable)objectiveTimeAvgPer10Min soloKillsAvgPer10Min:(SharedFloat * _Nullable)soloKillsAvgPer10Min timeSpentOnFireAvgPer10Min:(NSString * _Nullable)timeSpentOnFireAvgPer10Min __attribute__((swift_name("doCopy(assistsAvgPer10Min:deathsAvgPer10Min:eliminationsAvgPer10Min:finalBlowsAvgPer10Min:healingDoneAvgPer10Min:heroDamageDoneAvgPer10Min:objectiveContestTimeAvgPer10Min:objectiveKillsAvgPer10Min:objectiveTimeAvgPer10Min:soloKillsAvgPer10Min:timeSpentOnFireAvgPer10Min:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) SharedFloat * _Nullable assistsAvgPer10Min __attribute__((swift_name("assistsAvgPer10Min")));
@property (readonly) SharedFloat * _Nullable deathsAvgPer10Min __attribute__((swift_name("deathsAvgPer10Min")));
@property (readonly) SharedFloat * _Nullable eliminationsAvgPer10Min __attribute__((swift_name("eliminationsAvgPer10Min")));
@property (readonly) SharedFloat * _Nullable finalBlowsAvgPer10Min __attribute__((swift_name("finalBlowsAvgPer10Min")));
@property (readonly) SharedFloat * _Nullable healingDoneAvgPer10Min __attribute__((swift_name("healingDoneAvgPer10Min")));
@property (readonly) SharedFloat * _Nullable heroDamageDoneAvgPer10Min __attribute__((swift_name("heroDamageDoneAvgPer10Min")));
@property (readonly) NSString * _Nullable objectiveContestTimeAvgPer10Min __attribute__((swift_name("objectiveContestTimeAvgPer10Min")));
@property (readonly) SharedFloat * _Nullable objectiveKillsAvgPer10Min __attribute__((swift_name("objectiveKillsAvgPer10Min")));
@property (readonly) NSString * _Nullable objectiveTimeAvgPer10Min __attribute__((swift_name("objectiveTimeAvgPer10Min")));
@property (readonly) SharedFloat * _Nullable soloKillsAvgPer10Min __attribute__((swift_name("soloKillsAvgPer10Min")));
@property (readonly) NSString * _Nullable timeSpentOnFireAvgPer10Min __attribute__((swift_name("timeSpentOnFireAvgPer10Min")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Best")))
@interface SharedBest : SharedBase
- (instancetype)initWithAllDamageDoneMostInGame:(SharedInt * _Nullable)allDamageDoneMostInGame assistsMostInGame:(SharedInt * _Nullable)assistsMostInGame barrierDamageDoneMostInGame:(SharedInt * _Nullable)barrierDamageDoneMostInGame defensiveAssistsMostInGame:(SharedInt * _Nullable)defensiveAssistsMostInGame eliminationsMostInGame:(SharedInt * _Nullable)eliminationsMostInGame environmentalKillsMostInGame:(SharedInt * _Nullable)environmentalKillsMostInGame finalBlowsMostInGame:(SharedInt * _Nullable)finalBlowsMostInGame healingDoneMostInGame:(SharedInt * _Nullable)healingDoneMostInGame heroDamageDoneMostInGame:(SharedInt * _Nullable)heroDamageDoneMostInGame killsStreakBest:(SharedInt * _Nullable)killsStreakBest meleeFinalBlowsMostInGame:(SharedInt * _Nullable)meleeFinalBlowsMostInGame multikillsBest:(SharedInt * _Nullable)multikillsBest objectiveContestTimeMostInGame:(NSString * _Nullable)objectiveContestTimeMostInGame objectiveKillsMostInGame:(SharedInt * _Nullable)objectiveKillsMostInGame objectiveTimeMostInGame:(NSString * _Nullable)objectiveTimeMostInGame offensiveAssistsMostInGame:(SharedInt * _Nullable)offensiveAssistsMostInGame reconAssistsMostInGame:(SharedInt * _Nullable)reconAssistsMostInGame soloKillsMostInGame:(SharedInt * _Nullable)soloKillsMostInGame timeSpentOnFireMostInGame:(NSString * _Nullable)timeSpentOnFireMostInGame __attribute__((swift_name("init(allDamageDoneMostInGame:assistsMostInGame:barrierDamageDoneMostInGame:defensiveAssistsMostInGame:eliminationsMostInGame:environmentalKillsMostInGame:finalBlowsMostInGame:healingDoneMostInGame:heroDamageDoneMostInGame:killsStreakBest:meleeFinalBlowsMostInGame:multikillsBest:objectiveContestTimeMostInGame:objectiveKillsMostInGame:objectiveTimeMostInGame:offensiveAssistsMostInGame:reconAssistsMostInGame:soloKillsMostInGame:timeSpentOnFireMostInGame:)"))) __attribute__((objc_designated_initializer));
- (SharedBest *)doCopyAllDamageDoneMostInGame:(SharedInt * _Nullable)allDamageDoneMostInGame assistsMostInGame:(SharedInt * _Nullable)assistsMostInGame barrierDamageDoneMostInGame:(SharedInt * _Nullable)barrierDamageDoneMostInGame defensiveAssistsMostInGame:(SharedInt * _Nullable)defensiveAssistsMostInGame eliminationsMostInGame:(SharedInt * _Nullable)eliminationsMostInGame environmentalKillsMostInGame:(SharedInt * _Nullable)environmentalKillsMostInGame finalBlowsMostInGame:(SharedInt * _Nullable)finalBlowsMostInGame healingDoneMostInGame:(SharedInt * _Nullable)healingDoneMostInGame heroDamageDoneMostInGame:(SharedInt * _Nullable)heroDamageDoneMostInGame killsStreakBest:(SharedInt * _Nullable)killsStreakBest meleeFinalBlowsMostInGame:(SharedInt * _Nullable)meleeFinalBlowsMostInGame multikillsBest:(SharedInt * _Nullable)multikillsBest objectiveContestTimeMostInGame:(NSString * _Nullable)objectiveContestTimeMostInGame objectiveKillsMostInGame:(SharedInt * _Nullable)objectiveKillsMostInGame objectiveTimeMostInGame:(NSString * _Nullable)objectiveTimeMostInGame offensiveAssistsMostInGame:(SharedInt * _Nullable)offensiveAssistsMostInGame reconAssistsMostInGame:(SharedInt * _Nullable)reconAssistsMostInGame soloKillsMostInGame:(SharedInt * _Nullable)soloKillsMostInGame timeSpentOnFireMostInGame:(NSString * _Nullable)timeSpentOnFireMostInGame __attribute__((swift_name("doCopy(allDamageDoneMostInGame:assistsMostInGame:barrierDamageDoneMostInGame:defensiveAssistsMostInGame:eliminationsMostInGame:environmentalKillsMostInGame:finalBlowsMostInGame:healingDoneMostInGame:heroDamageDoneMostInGame:killsStreakBest:meleeFinalBlowsMostInGame:multikillsBest:objectiveContestTimeMostInGame:objectiveKillsMostInGame:objectiveTimeMostInGame:offensiveAssistsMostInGame:reconAssistsMostInGame:soloKillsMostInGame:timeSpentOnFireMostInGame:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) SharedInt * _Nullable allDamageDoneMostInGame __attribute__((swift_name("allDamageDoneMostInGame")));
@property (readonly) SharedInt * _Nullable assistsMostInGame __attribute__((swift_name("assistsMostInGame")));
@property (readonly) SharedInt * _Nullable barrierDamageDoneMostInGame __attribute__((swift_name("barrierDamageDoneMostInGame")));
@property (readonly) SharedInt * _Nullable defensiveAssistsMostInGame __attribute__((swift_name("defensiveAssistsMostInGame")));
@property (readonly) SharedInt * _Nullable eliminationsMostInGame __attribute__((swift_name("eliminationsMostInGame")));
@property (readonly) SharedInt * _Nullable environmentalKillsMostInGame __attribute__((swift_name("environmentalKillsMostInGame")));
@property (readonly) SharedInt * _Nullable finalBlowsMostInGame __attribute__((swift_name("finalBlowsMostInGame")));
@property (readonly) SharedInt * _Nullable healingDoneMostInGame __attribute__((swift_name("healingDoneMostInGame")));
@property (readonly) SharedInt * _Nullable heroDamageDoneMostInGame __attribute__((swift_name("heroDamageDoneMostInGame")));
@property (readonly) SharedInt * _Nullable killsStreakBest __attribute__((swift_name("killsStreakBest")));
@property (readonly) SharedInt * _Nullable meleeFinalBlowsMostInGame __attribute__((swift_name("meleeFinalBlowsMostInGame")));
@property (readonly) SharedInt * _Nullable multikillsBest __attribute__((swift_name("multikillsBest")));
@property (readonly) NSString * _Nullable objectiveContestTimeMostInGame __attribute__((swift_name("objectiveContestTimeMostInGame")));
@property (readonly) SharedInt * _Nullable objectiveKillsMostInGame __attribute__((swift_name("objectiveKillsMostInGame")));
@property (readonly) NSString * _Nullable objectiveTimeMostInGame __attribute__((swift_name("objectiveTimeMostInGame")));
@property (readonly) SharedInt * _Nullable offensiveAssistsMostInGame __attribute__((swift_name("offensiveAssistsMostInGame")));
@property (readonly) SharedInt * _Nullable reconAssistsMostInGame __attribute__((swift_name("reconAssistsMostInGame")));
@property (readonly) SharedInt * _Nullable soloKillsMostInGame __attribute__((swift_name("soloKillsMostInGame")));
@property (readonly) NSString * _Nullable timeSpentOnFireMostInGame __attribute__((swift_name("timeSpentOnFireMostInGame")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("CareerHeroStats")))
@interface SharedCareerHeroStats : SharedBase
- (instancetype)initWithName:(NSString *)name assists:(SharedAssists * _Nullable)assists average:(SharedAverage * _Nullable)average best:(SharedBest * _Nullable)best combat:(SharedCombat * _Nullable)combat heroSpecific:(SharedKotlinx_serialization_jsonJsonElement * _Nullable)heroSpecific game:(SharedGame *)game matchAwards:(SharedKotlinx_serialization_jsonJsonElement * _Nullable)matchAwards __attribute__((swift_name("init(name:assists:average:best:combat:heroSpecific:game:matchAwards:)"))) __attribute__((objc_designated_initializer));
- (SharedCareerHeroStats *)doCopyName:(NSString *)name assists:(SharedAssists * _Nullable)assists average:(SharedAverage * _Nullable)average best:(SharedBest * _Nullable)best combat:(SharedCombat * _Nullable)combat heroSpecific:(SharedKotlinx_serialization_jsonJsonElement * _Nullable)heroSpecific game:(SharedGame *)game matchAwards:(SharedKotlinx_serialization_jsonJsonElement * _Nullable)matchAwards __attribute__((swift_name("doCopy(name:assists:average:best:combat:heroSpecific:game:matchAwards:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) SharedAssists * _Nullable assists __attribute__((swift_name("assists")));
@property (readonly) SharedAverage * _Nullable average __attribute__((swift_name("average")));
@property (readonly) SharedBest * _Nullable best __attribute__((swift_name("best")));
@property (readonly) SharedCombat * _Nullable combat __attribute__((swift_name("combat")));
@property (readonly) SharedGame *game __attribute__((swift_name("game")));
@property (readonly) SharedKotlinx_serialization_jsonJsonElement * _Nullable heroSpecific __attribute__((swift_name("heroSpecific")));
@property (readonly) SharedKotlinx_serialization_jsonJsonElement * _Nullable matchAwards __attribute__((swift_name("matchAwards")));
@property (readonly) NSString *name __attribute__((swift_name("name")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Combat")))
@interface SharedCombat : SharedBase
- (instancetype)initWithDamageDone:(SharedInt * _Nullable)damageDone deaths:(SharedInt * _Nullable)deaths eliminations:(SharedInt * _Nullable)eliminations environmentalKills:(SharedInt * _Nullable)environmentalKills finalBlows:(SharedInt * _Nullable)finalBlows heroDamageDone:(SharedInt * _Nullable)heroDamageDone meleeFinalBlows:(SharedInt * _Nullable)meleeFinalBlows multikills:(SharedInt * _Nullable)multikills objectiveContestTime:(NSString * _Nullable)objectiveContestTime objectiveKills:(SharedInt * _Nullable)objectiveKills objectiveTime:(NSString * _Nullable)objectiveTime soloKills:(SharedInt * _Nullable)soloKills timeSpentOnFire:(NSString * _Nullable)timeSpentOnFire __attribute__((swift_name("init(damageDone:deaths:eliminations:environmentalKills:finalBlows:heroDamageDone:meleeFinalBlows:multikills:objectiveContestTime:objectiveKills:objectiveTime:soloKills:timeSpentOnFire:)"))) __attribute__((objc_designated_initializer));
- (SharedCombat *)doCopyDamageDone:(SharedInt * _Nullable)damageDone deaths:(SharedInt * _Nullable)deaths eliminations:(SharedInt * _Nullable)eliminations environmentalKills:(SharedInt * _Nullable)environmentalKills finalBlows:(SharedInt * _Nullable)finalBlows heroDamageDone:(SharedInt * _Nullable)heroDamageDone meleeFinalBlows:(SharedInt * _Nullable)meleeFinalBlows multikills:(SharedInt * _Nullable)multikills objectiveContestTime:(NSString * _Nullable)objectiveContestTime objectiveKills:(SharedInt * _Nullable)objectiveKills objectiveTime:(NSString * _Nullable)objectiveTime soloKills:(SharedInt * _Nullable)soloKills timeSpentOnFire:(NSString * _Nullable)timeSpentOnFire __attribute__((swift_name("doCopy(damageDone:deaths:eliminations:environmentalKills:finalBlows:heroDamageDone:meleeFinalBlows:multikills:objectiveContestTime:objectiveKills:objectiveTime:soloKills:timeSpentOnFire:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) SharedInt * _Nullable damageDone __attribute__((swift_name("damageDone")));
@property (readonly) SharedInt * _Nullable deaths __attribute__((swift_name("deaths")));
@property (readonly) SharedInt * _Nullable eliminations __attribute__((swift_name("eliminations")));
@property (readonly) SharedInt * _Nullable environmentalKills __attribute__((swift_name("environmentalKills")));
@property (readonly) SharedInt * _Nullable finalBlows __attribute__((swift_name("finalBlows")));
@property (readonly) SharedInt * _Nullable heroDamageDone __attribute__((swift_name("heroDamageDone")));
@property (readonly) SharedInt * _Nullable meleeFinalBlows __attribute__((swift_name("meleeFinalBlows")));
@property (readonly) SharedInt * _Nullable multikills __attribute__((swift_name("multikills")));
@property (readonly) NSString * _Nullable objectiveContestTime __attribute__((swift_name("objectiveContestTime")));
@property (readonly) SharedInt * _Nullable objectiveKills __attribute__((swift_name("objectiveKills")));
@property (readonly) NSString * _Nullable objectiveTime __attribute__((swift_name("objectiveTime")));
@property (readonly) SharedInt * _Nullable soloKills __attribute__((swift_name("soloKills")));
@property (readonly) NSString * _Nullable timeSpentOnFire __attribute__((swift_name("timeSpentOnFire")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("CompetitiveStats")))
@interface SharedCompetitiveStats : SharedBase
- (instancetype)initWithSeason:(int32_t)season topHeroes:(NSArray<SharedTopHero *> *)topHeroes careerStats:(NSArray<SharedCareerHeroStats *> *)careerStats __attribute__((swift_name("init(season:topHeroes:careerStats:)"))) __attribute__((objc_designated_initializer));
- (SharedCompetitiveStats *)doCopySeason:(int32_t)season topHeroes:(NSArray<SharedTopHero *> *)topHeroes careerStats:(NSArray<SharedCareerHeroStats *> *)careerStats __attribute__((swift_name("doCopy(season:topHeroes:careerStats:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSArray<SharedCareerHeroStats *> *careerStats __attribute__((swift_name("careerStats")));
@property (readonly) int32_t season __attribute__((swift_name("season")));
@property (readonly) NSArray<SharedTopHero *> *topHeroes __attribute__((swift_name("topHeroes")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Game")))
@interface SharedGame : SharedBase
- (instancetype)initWithGamesLost:(int32_t)gamesLost gamesPlayed:(SharedInt * _Nullable)gamesPlayed gamesWon:(SharedInt * _Nullable)gamesWon heroWins:(SharedInt * _Nullable)heroWins timePlayed:(NSString *)timePlayed __attribute__((swift_name("init(gamesLost:gamesPlayed:gamesWon:heroWins:timePlayed:)"))) __attribute__((objc_designated_initializer));
- (SharedGame *)doCopyGamesLost:(int32_t)gamesLost gamesPlayed:(SharedInt * _Nullable)gamesPlayed gamesWon:(SharedInt * _Nullable)gamesWon heroWins:(SharedInt * _Nullable)heroWins timePlayed:(NSString *)timePlayed __attribute__((swift_name("doCopy(gamesLost:gamesPlayed:gamesWon:heroWins:timePlayed:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) int32_t gamesLost __attribute__((swift_name("gamesLost")));
@property (readonly) SharedInt * _Nullable gamesPlayed __attribute__((swift_name("gamesPlayed")));
@property (readonly) SharedInt * _Nullable gamesWon __attribute__((swift_name("gamesWon")));
@property (readonly) SharedInt * _Nullable heroWins __attribute__((swift_name("heroWins")));
@property (readonly) NSString *timePlayed __attribute__((swift_name("timePlayed")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("PlayerProfileStats")))
@interface SharedPlayerProfileStats : SharedBase
- (instancetype)initWithIcon:(NSString *)icon name:(NSString *)name endorsement:(int32_t)endorsement endorsementIcon:(NSString *)endorsementIcon title:(NSString *)title ratings:(NSArray<SharedRating *> * _Nullable)ratings gamesWon:(int32_t)gamesWon gamesLost:(int32_t)gamesLost gamesPlayed:(int32_t)gamesPlayed private:(BOOL)private_ quickPlayStats:(SharedQuickPlayStats *)quickPlayStats competitiveStats:(SharedCompetitiveStats *)competitiveStats __attribute__((swift_name("init(icon:name:endorsement:endorsementIcon:title:ratings:gamesWon:gamesLost:gamesPlayed:private:quickPlayStats:competitiveStats:)"))) __attribute__((objc_designated_initializer));
- (SharedPlayerProfileStats *)doCopyIcon:(NSString *)icon name:(NSString *)name endorsement:(int32_t)endorsement endorsementIcon:(NSString *)endorsementIcon title:(NSString *)title ratings:(NSArray<SharedRating *> * _Nullable)ratings gamesWon:(int32_t)gamesWon gamesLost:(int32_t)gamesLost gamesPlayed:(int32_t)gamesPlayed private:(BOOL)private_ quickPlayStats:(SharedQuickPlayStats *)quickPlayStats competitiveStats:(SharedCompetitiveStats *)competitiveStats __attribute__((swift_name("doCopy(icon:name:endorsement:endorsementIcon:title:ratings:gamesWon:gamesLost:gamesPlayed:private:quickPlayStats:competitiveStats:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) SharedCompetitiveStats *competitiveStats __attribute__((swift_name("competitiveStats")));
@property (readonly) int32_t endorsement __attribute__((swift_name("endorsement")));
@property (readonly) NSString *endorsementIcon __attribute__((swift_name("endorsementIcon")));
@property (readonly) int32_t gamesLost __attribute__((swift_name("gamesLost")));
@property (readonly) int32_t gamesPlayed __attribute__((swift_name("gamesPlayed")));
@property (readonly) int32_t gamesWon __attribute__((swift_name("gamesWon")));
@property (readonly) NSString *icon __attribute__((swift_name("icon")));
@property (readonly) NSString *name __attribute__((swift_name("name")));
@property (readonly, getter=private) BOOL private_ __attribute__((swift_name("private_")));
@property (readonly) SharedQuickPlayStats *quickPlayStats __attribute__((swift_name("quickPlayStats")));
@property (readonly) NSArray<SharedRating *> * _Nullable ratings __attribute__((swift_name("ratings")));
@property (readonly) NSString *title __attribute__((swift_name("title")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("QuickPlayStats")))
@interface SharedQuickPlayStats : SharedBase
- (instancetype)initWithTopHeroes:(NSArray<SharedTopHero *> *)topHeroes careerStats:(NSArray<SharedCareerHeroStats *> *)careerStats __attribute__((swift_name("init(topHeroes:careerStats:)"))) __attribute__((objc_designated_initializer));
- (SharedQuickPlayStats *)doCopyTopHeroes:(NSArray<SharedTopHero *> *)topHeroes careerStats:(NSArray<SharedCareerHeroStats *> *)careerStats __attribute__((swift_name("doCopy(topHeroes:careerStats:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSArray<SharedCareerHeroStats *> *careerStats __attribute__((swift_name("careerStats")));
@property (readonly) NSArray<SharedTopHero *> *topHeroes __attribute__((swift_name("topHeroes")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Rating")))
@interface SharedRating : SharedBase
- (instancetype)initWithGroup:(NSString *)group tier:(int32_t)tier role:(NSString *)role roleIcon:(NSString *)roleIcon rankIcon:(NSString *)rankIcon tierIcon:(NSString *)tierIcon __attribute__((swift_name("init(group:tier:role:roleIcon:rankIcon:tierIcon:)"))) __attribute__((objc_designated_initializer));
- (SharedRating *)doCopyGroup:(NSString *)group tier:(int32_t)tier role:(NSString *)role roleIcon:(NSString *)roleIcon rankIcon:(NSString *)rankIcon tierIcon:(NSString *)tierIcon __attribute__((swift_name("doCopy(group:tier:role:roleIcon:rankIcon:tierIcon:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *group __attribute__((swift_name("group")));
@property (readonly) NSString *rankIcon __attribute__((swift_name("rankIcon")));
@property (readonly) NSString *role __attribute__((swift_name("role")));
@property (readonly) NSString *roleIcon __attribute__((swift_name("roleIcon")));
@property (readonly) int32_t tier __attribute__((swift_name("tier")));
@property (readonly) NSString *tierIcon __attribute__((swift_name("tierIcon")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("TopHero")))
@interface SharedTopHero : SharedBase
- (instancetype)initWithName:(NSString *)name timePlayed:(NSString *)timePlayed gamesWon:(int32_t)gamesWon weaponAccuracy:(float)weaponAccuracy criticalHitAccuracy:(float)criticalHitAccuracy eliminationsPerLife:(float)eliminationsPerLife multiKillBest:(int32_t)multiKillBest objectiveKills:(int32_t)objectiveKills __attribute__((swift_name("init(name:timePlayed:gamesWon:weaponAccuracy:criticalHitAccuracy:eliminationsPerLife:multiKillBest:objectiveKills:)"))) __attribute__((objc_designated_initializer));
- (SharedTopHero *)doCopyName:(NSString *)name timePlayed:(NSString *)timePlayed gamesWon:(int32_t)gamesWon weaponAccuracy:(float)weaponAccuracy criticalHitAccuracy:(float)criticalHitAccuracy eliminationsPerLife:(float)eliminationsPerLife multiKillBest:(int32_t)multiKillBest objectiveKills:(int32_t)objectiveKills __attribute__((swift_name("doCopy(name:timePlayed:gamesWon:weaponAccuracy:criticalHitAccuracy:eliminationsPerLife:multiKillBest:objectiveKills:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) float criticalHitAccuracy __attribute__((swift_name("criticalHitAccuracy")));
@property (readonly) float eliminationsPerLife __attribute__((swift_name("eliminationsPerLife")));
@property (readonly) int32_t gamesWon __attribute__((swift_name("gamesWon")));
@property (readonly) int32_t multiKillBest __attribute__((swift_name("multiKillBest")));
@property (readonly) NSString *name __attribute__((swift_name("name")));
@property (readonly) int32_t objectiveKills __attribute__((swift_name("objectiveKills")));
@property (readonly) NSString *timePlayed __attribute__((swift_name("timePlayed")));
@property (readonly) int64_t timePlayedDuration __attribute__((swift_name("timePlayedDuration")));
@property (readonly) float weaponAccuracy __attribute__((swift_name("weaponAccuracy")));
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable
*/
__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("OverwatchPlayer")))
@interface SharedOverwatchPlayer : SharedBase
- (instancetype)initWithBattleTag:(NSString *)battleTag frame:(NSString * _Nullable)frame isPublic:(BOOL)isPublic lastUpdated:(int64_t)lastUpdated namecard:(NSString * _Nullable)namecard portrait:(NSString * _Nullable)portrait title:(NSString * _Nullable)title url:(NSString *)url __attribute__((swift_name("init(battleTag:frame:isPublic:lastUpdated:namecard:portrait:title:url:)"))) __attribute__((objc_designated_initializer));
@property (class, readonly, getter=companion) SharedOverwatchPlayerCompanion *companion __attribute__((swift_name("companion")));
- (SharedOverwatchPlayer *)doCopyBattleTag:(NSString *)battleTag frame:(NSString * _Nullable)frame isPublic:(BOOL)isPublic lastUpdated:(int64_t)lastUpdated namecard:(NSString * _Nullable)namecard portrait:(NSString * _Nullable)portrait title:(NSString * _Nullable)title url:(NSString *)url __attribute__((swift_name("doCopy(battleTag:frame:isPublic:lastUpdated:namecard:portrait:title:url:)")));
- (BOOL)isEqual:(id _Nullable)other __attribute__((swift_name("isEqual(_:)")));
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) NSString *battleTag __attribute__((swift_name("battleTag")));
@property (readonly) NSString * _Nullable frame __attribute__((swift_name("frame")));
@property (readonly) BOOL isPublic __attribute__((swift_name("isPublic")));
@property (readonly) int64_t lastUpdated __attribute__((swift_name("lastUpdated")));
@property (readonly) NSString * _Nullable namecard __attribute__((swift_name("namecard")));
@property (readonly) NSString * _Nullable portrait __attribute__((swift_name("portrait")));
@property (readonly) NSString * _Nullable title __attribute__((swift_name("title")));
@property (readonly) NSString *url __attribute__((swift_name("url")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("OverwatchPlayer.Companion")))
@interface SharedOverwatchPlayerCompanion : SharedBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SharedOverwatchPlayerCompanion *shared __attribute__((swift_name("shared")));
- (id<SharedKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end

__attribute__((swift_name("KotlinThrowable")))
@interface SharedKotlinThrowable : SharedBase
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (instancetype)initWithMessage:(NSString * _Nullable)message __attribute__((swift_name("init(message:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithCause:(SharedKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(cause:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithMessage:(NSString * _Nullable)message cause:(SharedKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(message:cause:)"))) __attribute__((objc_designated_initializer));

/**
 * @note annotations
 *   kotlin.experimental.ExperimentalNativeApi
*/
- (SharedKotlinArray<NSString *> *)getStackTrace __attribute__((swift_name("getStackTrace()")));
- (void)printStackTrace __attribute__((swift_name("printStackTrace()")));
- (NSString *)description __attribute__((swift_name("description()")));
@property (readonly) SharedKotlinThrowable * _Nullable cause __attribute__((swift_name("cause")));
@property (readonly) NSString * _Nullable message __attribute__((swift_name("message")));
- (NSError *)asError __attribute__((swift_name("asError()")));
@end

__attribute__((swift_name("KotlinException")))
@interface SharedKotlinException : SharedKotlinThrowable
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (instancetype)initWithMessage:(NSString * _Nullable)message __attribute__((swift_name("init(message:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithCause:(SharedKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(cause:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithMessage:(NSString * _Nullable)message cause:(SharedKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(message:cause:)"))) __attribute__((objc_designated_initializer));
@end

__attribute__((swift_name("KotlinRuntimeException")))
@interface SharedKotlinRuntimeException : SharedKotlinException
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (instancetype)initWithMessage:(NSString * _Nullable)message __attribute__((swift_name("init(message:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithCause:(SharedKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(cause:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithMessage:(NSString * _Nullable)message cause:(SharedKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(message:cause:)"))) __attribute__((objc_designated_initializer));
@end

__attribute__((swift_name("KotlinIllegalStateException")))
@interface SharedKotlinIllegalStateException : SharedKotlinRuntimeException
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (instancetype)initWithMessage:(NSString * _Nullable)message __attribute__((swift_name("init(message:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithCause:(SharedKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(cause:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithMessage:(NSString * _Nullable)message cause:(SharedKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(message:cause:)"))) __attribute__((objc_designated_initializer));
@end


/**
 * @note annotations
 *   kotlin.SinceKotlin(version="1.4")
*/
__attribute__((swift_name("KotlinCancellationException")))
@interface SharedKotlinCancellationException : SharedKotlinIllegalStateException
- (instancetype)init __attribute__((swift_name("init()"))) __attribute__((objc_designated_initializer));
+ (instancetype)new __attribute__((availability(swift, unavailable, message="use object initializers instead")));
- (instancetype)initWithMessage:(NSString * _Nullable)message __attribute__((swift_name("init(message:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithCause:(SharedKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(cause:)"))) __attribute__((objc_designated_initializer));
- (instancetype)initWithMessage:(NSString * _Nullable)message cause:(SharedKotlinThrowable * _Nullable)cause __attribute__((swift_name("init(message:cause:)"))) __attribute__((objc_designated_initializer));
@end

__attribute__((swift_name("Kotlinx_serialization_coreSerializationStrategy")))
@protocol SharedKotlinx_serialization_coreSerializationStrategy
@required
- (void)serializeEncoder:(id<SharedKotlinx_serialization_coreEncoder>)encoder value:(id _Nullable)value __attribute__((swift_name("serialize(encoder:value:)")));
@property (readonly) id<SharedKotlinx_serialization_coreSerialDescriptor> descriptor __attribute__((swift_name("descriptor")));
@end

__attribute__((swift_name("Kotlinx_serialization_coreDeserializationStrategy")))
@protocol SharedKotlinx_serialization_coreDeserializationStrategy
@required
- (id _Nullable)deserializeDecoder:(id<SharedKotlinx_serialization_coreDecoder>)decoder __attribute__((swift_name("deserialize(decoder:)")));
@property (readonly) id<SharedKotlinx_serialization_coreSerialDescriptor> descriptor __attribute__((swift_name("descriptor")));
@end

__attribute__((swift_name("Kotlinx_serialization_coreKSerializer")))
@protocol SharedKotlinx_serialization_coreKSerializer <SharedKotlinx_serialization_coreSerializationStrategy, SharedKotlinx_serialization_coreDeserializationStrategy>
@required
@end


/**
 * @note annotations
 *   kotlinx.serialization.Serializable(with=NormalClass(value=kotlinx/serialization/json/JsonElementSerializer))
*/
__attribute__((swift_name("Kotlinx_serialization_jsonJsonElement")))
@interface SharedKotlinx_serialization_jsonJsonElement : SharedBase
@property (class, readonly, getter=companion) SharedKotlinx_serialization_jsonJsonElementCompanion *companion __attribute__((swift_name("companion")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("KotlinArray")))
@interface SharedKotlinArray<T> : SharedBase
+ (instancetype)arrayWithSize:(int32_t)size init:(T _Nullable (^)(SharedInt *))init __attribute__((swift_name("init(size:init:)")));
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
- (T _Nullable)getIndex:(int32_t)index __attribute__((swift_name("get(index:)")));
- (id<SharedKotlinIterator>)iterator __attribute__((swift_name("iterator()")));
- (void)setIndex:(int32_t)index value:(T _Nullable)value __attribute__((swift_name("set(index:value:)")));
@property (readonly) int32_t size __attribute__((swift_name("size")));
@end

__attribute__((swift_name("Kotlinx_serialization_coreEncoder")))
@protocol SharedKotlinx_serialization_coreEncoder
@required
- (id<SharedKotlinx_serialization_coreCompositeEncoder>)beginCollectionDescriptor:(id<SharedKotlinx_serialization_coreSerialDescriptor>)descriptor collectionSize:(int32_t)collectionSize __attribute__((swift_name("beginCollection(descriptor:collectionSize:)")));
- (id<SharedKotlinx_serialization_coreCompositeEncoder>)beginStructureDescriptor:(id<SharedKotlinx_serialization_coreSerialDescriptor>)descriptor __attribute__((swift_name("beginStructure(descriptor:)")));
- (void)encodeBooleanValue:(BOOL)value __attribute__((swift_name("encodeBoolean(value:)")));
- (void)encodeByteValue:(int8_t)value __attribute__((swift_name("encodeByte(value:)")));
- (void)encodeCharValue:(unichar)value __attribute__((swift_name("encodeChar(value:)")));
- (void)encodeDoubleValue:(double)value __attribute__((swift_name("encodeDouble(value:)")));
- (void)encodeEnumEnumDescriptor:(id<SharedKotlinx_serialization_coreSerialDescriptor>)enumDescriptor index:(int32_t)index __attribute__((swift_name("encodeEnum(enumDescriptor:index:)")));
- (void)encodeFloatValue:(float)value __attribute__((swift_name("encodeFloat(value:)")));
- (id<SharedKotlinx_serialization_coreEncoder>)encodeInlineDescriptor:(id<SharedKotlinx_serialization_coreSerialDescriptor>)descriptor __attribute__((swift_name("encodeInline(descriptor:)")));
- (void)encodeIntValue:(int32_t)value __attribute__((swift_name("encodeInt(value:)")));
- (void)encodeLongValue:(int64_t)value __attribute__((swift_name("encodeLong(value:)")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (void)encodeNotNullMark __attribute__((swift_name("encodeNotNullMark()")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (void)encodeNull __attribute__((swift_name("encodeNull()")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (void)encodeNullableSerializableValueSerializer:(id<SharedKotlinx_serialization_coreSerializationStrategy>)serializer value:(id _Nullable)value __attribute__((swift_name("encodeNullableSerializableValue(serializer:value:)")));
- (void)encodeSerializableValueSerializer:(id<SharedKotlinx_serialization_coreSerializationStrategy>)serializer value:(id _Nullable)value __attribute__((swift_name("encodeSerializableValue(serializer:value:)")));
- (void)encodeShortValue:(int16_t)value __attribute__((swift_name("encodeShort(value:)")));
- (void)encodeStringValue:(NSString *)value __attribute__((swift_name("encodeString(value:)")));
@property (readonly) SharedKotlinx_serialization_coreSerializersModule *serializersModule __attribute__((swift_name("serializersModule")));
@end

__attribute__((swift_name("Kotlinx_serialization_coreSerialDescriptor")))
@protocol SharedKotlinx_serialization_coreSerialDescriptor
@required
- (NSArray<id<SharedKotlinAnnotation>> *)getElementAnnotationsIndex:(int32_t)index __attribute__((swift_name("getElementAnnotations(index:)")));
- (id<SharedKotlinx_serialization_coreSerialDescriptor>)getElementDescriptorIndex:(int32_t)index __attribute__((swift_name("getElementDescriptor(index:)")));
- (int32_t)getElementIndexName:(NSString *)name __attribute__((swift_name("getElementIndex(name:)")));
- (NSString *)getElementNameIndex:(int32_t)index __attribute__((swift_name("getElementName(index:)")));
- (BOOL)isElementOptionalIndex:(int32_t)index __attribute__((swift_name("isElementOptional(index:)")));
@property (readonly) NSArray<id<SharedKotlinAnnotation>> *annotations __attribute__((swift_name("annotations")));
@property (readonly) int32_t elementsCount __attribute__((swift_name("elementsCount")));
@property (readonly) BOOL isInline __attribute__((swift_name("isInline")));
@property (readonly) BOOL isNullable __attribute__((swift_name("isNullable")));
@property (readonly) SharedKotlinx_serialization_coreSerialKind *kind __attribute__((swift_name("kind")));
@property (readonly) NSString *serialName __attribute__((swift_name("serialName")));
@end

__attribute__((swift_name("Kotlinx_serialization_coreDecoder")))
@protocol SharedKotlinx_serialization_coreDecoder
@required
- (id<SharedKotlinx_serialization_coreCompositeDecoder>)beginStructureDescriptor:(id<SharedKotlinx_serialization_coreSerialDescriptor>)descriptor __attribute__((swift_name("beginStructure(descriptor:)")));
- (BOOL)decodeBoolean __attribute__((swift_name("decodeBoolean()")));
- (int8_t)decodeByte __attribute__((swift_name("decodeByte()")));
- (unichar)decodeChar __attribute__((swift_name("decodeChar()")));
- (double)decodeDouble __attribute__((swift_name("decodeDouble()")));
- (int32_t)decodeEnumEnumDescriptor:(id<SharedKotlinx_serialization_coreSerialDescriptor>)enumDescriptor __attribute__((swift_name("decodeEnum(enumDescriptor:)")));
- (float)decodeFloat __attribute__((swift_name("decodeFloat()")));
- (id<SharedKotlinx_serialization_coreDecoder>)decodeInlineDescriptor:(id<SharedKotlinx_serialization_coreSerialDescriptor>)descriptor __attribute__((swift_name("decodeInline(descriptor:)")));
- (int32_t)decodeInt __attribute__((swift_name("decodeInt()")));
- (int64_t)decodeLong __attribute__((swift_name("decodeLong()")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (BOOL)decodeNotNullMark __attribute__((swift_name("decodeNotNullMark()")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (SharedKotlinNothing * _Nullable)decodeNull __attribute__((swift_name("decodeNull()")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (id _Nullable)decodeNullableSerializableValueDeserializer:(id<SharedKotlinx_serialization_coreDeserializationStrategy>)deserializer __attribute__((swift_name("decodeNullableSerializableValue(deserializer:)")));
- (id _Nullable)decodeSerializableValueDeserializer:(id<SharedKotlinx_serialization_coreDeserializationStrategy>)deserializer __attribute__((swift_name("decodeSerializableValue(deserializer:)")));
- (int16_t)decodeShort __attribute__((swift_name("decodeShort()")));
- (NSString *)decodeString __attribute__((swift_name("decodeString()")));
@property (readonly) SharedKotlinx_serialization_coreSerializersModule *serializersModule __attribute__((swift_name("serializersModule")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("Kotlinx_serialization_jsonJsonElement.Companion")))
@interface SharedKotlinx_serialization_jsonJsonElementCompanion : SharedBase
+ (instancetype)alloc __attribute__((unavailable));
+ (instancetype)allocWithZone:(struct _NSZone *)zone __attribute__((unavailable));
+ (instancetype)companion __attribute__((swift_name("init()")));
@property (class, readonly, getter=shared) SharedKotlinx_serialization_jsonJsonElementCompanion *shared __attribute__((swift_name("shared")));
- (id<SharedKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("serializer()")));
@end

__attribute__((swift_name("KotlinIterator")))
@protocol SharedKotlinIterator
@required
- (BOOL)hasNext __attribute__((swift_name("hasNext()")));
- (id _Nullable)next __attribute__((swift_name("next()")));
@end

__attribute__((swift_name("Kotlinx_serialization_coreCompositeEncoder")))
@protocol SharedKotlinx_serialization_coreCompositeEncoder
@required
- (void)encodeBooleanElementDescriptor:(id<SharedKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index value:(BOOL)value __attribute__((swift_name("encodeBooleanElement(descriptor:index:value:)")));
- (void)encodeByteElementDescriptor:(id<SharedKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index value:(int8_t)value __attribute__((swift_name("encodeByteElement(descriptor:index:value:)")));
- (void)encodeCharElementDescriptor:(id<SharedKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index value:(unichar)value __attribute__((swift_name("encodeCharElement(descriptor:index:value:)")));
- (void)encodeDoubleElementDescriptor:(id<SharedKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index value:(double)value __attribute__((swift_name("encodeDoubleElement(descriptor:index:value:)")));
- (void)encodeFloatElementDescriptor:(id<SharedKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index value:(float)value __attribute__((swift_name("encodeFloatElement(descriptor:index:value:)")));
- (id<SharedKotlinx_serialization_coreEncoder>)encodeInlineElementDescriptor:(id<SharedKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("encodeInlineElement(descriptor:index:)")));
- (void)encodeIntElementDescriptor:(id<SharedKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index value:(int32_t)value __attribute__((swift_name("encodeIntElement(descriptor:index:value:)")));
- (void)encodeLongElementDescriptor:(id<SharedKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index value:(int64_t)value __attribute__((swift_name("encodeLongElement(descriptor:index:value:)")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (void)encodeNullableSerializableElementDescriptor:(id<SharedKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index serializer:(id<SharedKotlinx_serialization_coreSerializationStrategy>)serializer value:(id _Nullable)value __attribute__((swift_name("encodeNullableSerializableElement(descriptor:index:serializer:value:)")));
- (void)encodeSerializableElementDescriptor:(id<SharedKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index serializer:(id<SharedKotlinx_serialization_coreSerializationStrategy>)serializer value:(id _Nullable)value __attribute__((swift_name("encodeSerializableElement(descriptor:index:serializer:value:)")));
- (void)encodeShortElementDescriptor:(id<SharedKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index value:(int16_t)value __attribute__((swift_name("encodeShortElement(descriptor:index:value:)")));
- (void)encodeStringElementDescriptor:(id<SharedKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index value:(NSString *)value __attribute__((swift_name("encodeStringElement(descriptor:index:value:)")));
- (void)endStructureDescriptor:(id<SharedKotlinx_serialization_coreSerialDescriptor>)descriptor __attribute__((swift_name("endStructure(descriptor:)")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (BOOL)shouldEncodeElementDefaultDescriptor:(id<SharedKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("shouldEncodeElementDefault(descriptor:index:)")));
@property (readonly) SharedKotlinx_serialization_coreSerializersModule *serializersModule __attribute__((swift_name("serializersModule")));
@end

__attribute__((swift_name("Kotlinx_serialization_coreSerializersModule")))
@interface SharedKotlinx_serialization_coreSerializersModule : SharedBase

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (void)dumpToCollector:(id<SharedKotlinx_serialization_coreSerializersModuleCollector>)collector __attribute__((swift_name("dumpTo(collector:)")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (id<SharedKotlinx_serialization_coreKSerializer> _Nullable)getContextualKClass:(id<SharedKotlinKClass>)kClass typeArgumentsSerializers:(NSArray<id<SharedKotlinx_serialization_coreKSerializer>> *)typeArgumentsSerializers __attribute__((swift_name("getContextual(kClass:typeArgumentsSerializers:)")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (id<SharedKotlinx_serialization_coreSerializationStrategy> _Nullable)getPolymorphicBaseClass:(id<SharedKotlinKClass>)baseClass value:(id)value __attribute__((swift_name("getPolymorphic(baseClass:value:)")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (id<SharedKotlinx_serialization_coreDeserializationStrategy> _Nullable)getPolymorphicBaseClass:(id<SharedKotlinKClass>)baseClass serializedClassName:(NSString * _Nullable)serializedClassName __attribute__((swift_name("getPolymorphic(baseClass:serializedClassName:)")));
@end

__attribute__((swift_name("KotlinAnnotation")))
@protocol SharedKotlinAnnotation
@required
@end

__attribute__((swift_name("Kotlinx_serialization_coreSerialKind")))
@interface SharedKotlinx_serialization_coreSerialKind : SharedBase
- (NSUInteger)hash __attribute__((swift_name("hash()")));
- (NSString *)description __attribute__((swift_name("description()")));
@end

__attribute__((swift_name("Kotlinx_serialization_coreCompositeDecoder")))
@protocol SharedKotlinx_serialization_coreCompositeDecoder
@required
- (BOOL)decodeBooleanElementDescriptor:(id<SharedKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("decodeBooleanElement(descriptor:index:)")));
- (int8_t)decodeByteElementDescriptor:(id<SharedKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("decodeByteElement(descriptor:index:)")));
- (unichar)decodeCharElementDescriptor:(id<SharedKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("decodeCharElement(descriptor:index:)")));
- (int32_t)decodeCollectionSizeDescriptor:(id<SharedKotlinx_serialization_coreSerialDescriptor>)descriptor __attribute__((swift_name("decodeCollectionSize(descriptor:)")));
- (double)decodeDoubleElementDescriptor:(id<SharedKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("decodeDoubleElement(descriptor:index:)")));
- (int32_t)decodeElementIndexDescriptor:(id<SharedKotlinx_serialization_coreSerialDescriptor>)descriptor __attribute__((swift_name("decodeElementIndex(descriptor:)")));
- (float)decodeFloatElementDescriptor:(id<SharedKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("decodeFloatElement(descriptor:index:)")));
- (id<SharedKotlinx_serialization_coreDecoder>)decodeInlineElementDescriptor:(id<SharedKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("decodeInlineElement(descriptor:index:)")));
- (int32_t)decodeIntElementDescriptor:(id<SharedKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("decodeIntElement(descriptor:index:)")));
- (int64_t)decodeLongElementDescriptor:(id<SharedKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("decodeLongElement(descriptor:index:)")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (id _Nullable)decodeNullableSerializableElementDescriptor:(id<SharedKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index deserializer:(id<SharedKotlinx_serialization_coreDeserializationStrategy>)deserializer previousValue:(id _Nullable)previousValue __attribute__((swift_name("decodeNullableSerializableElement(descriptor:index:deserializer:previousValue:)")));

/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
- (BOOL)decodeSequentially __attribute__((swift_name("decodeSequentially()")));
- (id _Nullable)decodeSerializableElementDescriptor:(id<SharedKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index deserializer:(id<SharedKotlinx_serialization_coreDeserializationStrategy>)deserializer previousValue:(id _Nullable)previousValue __attribute__((swift_name("decodeSerializableElement(descriptor:index:deserializer:previousValue:)")));
- (int16_t)decodeShortElementDescriptor:(id<SharedKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("decodeShortElement(descriptor:index:)")));
- (NSString *)decodeStringElementDescriptor:(id<SharedKotlinx_serialization_coreSerialDescriptor>)descriptor index:(int32_t)index __attribute__((swift_name("decodeStringElement(descriptor:index:)")));
- (void)endStructureDescriptor:(id<SharedKotlinx_serialization_coreSerialDescriptor>)descriptor __attribute__((swift_name("endStructure(descriptor:)")));
@property (readonly) SharedKotlinx_serialization_coreSerializersModule *serializersModule __attribute__((swift_name("serializersModule")));
@end

__attribute__((objc_subclassing_restricted))
__attribute__((swift_name("KotlinNothing")))
@interface SharedKotlinNothing : SharedBase
@end


/**
 * @note annotations
 *   kotlinx.serialization.ExperimentalSerializationApi
*/
__attribute__((swift_name("Kotlinx_serialization_coreSerializersModuleCollector")))
@protocol SharedKotlinx_serialization_coreSerializersModuleCollector
@required
- (void)contextualKClass:(id<SharedKotlinKClass>)kClass provider:(id<SharedKotlinx_serialization_coreKSerializer> (^)(NSArray<id<SharedKotlinx_serialization_coreKSerializer>> *))provider __attribute__((swift_name("contextual(kClass:provider:)")));
- (void)contextualKClass:(id<SharedKotlinKClass>)kClass serializer:(id<SharedKotlinx_serialization_coreKSerializer>)serializer __attribute__((swift_name("contextual(kClass:serializer:)")));
- (void)polymorphicBaseClass:(id<SharedKotlinKClass>)baseClass actualClass:(id<SharedKotlinKClass>)actualClass actualSerializer:(id<SharedKotlinx_serialization_coreKSerializer>)actualSerializer __attribute__((swift_name("polymorphic(baseClass:actualClass:actualSerializer:)")));
- (void)polymorphicDefaultBaseClass:(id<SharedKotlinKClass>)baseClass defaultDeserializerProvider:(id<SharedKotlinx_serialization_coreDeserializationStrategy> _Nullable (^)(NSString * _Nullable))defaultDeserializerProvider __attribute__((swift_name("polymorphicDefault(baseClass:defaultDeserializerProvider:)"))) __attribute__((deprecated("Deprecated in favor of function with more precise name: polymorphicDefaultDeserializer")));
- (void)polymorphicDefaultDeserializerBaseClass:(id<SharedKotlinKClass>)baseClass defaultDeserializerProvider:(id<SharedKotlinx_serialization_coreDeserializationStrategy> _Nullable (^)(NSString * _Nullable))defaultDeserializerProvider __attribute__((swift_name("polymorphicDefaultDeserializer(baseClass:defaultDeserializerProvider:)")));
- (void)polymorphicDefaultSerializerBaseClass:(id<SharedKotlinKClass>)baseClass defaultSerializerProvider:(id<SharedKotlinx_serialization_coreSerializationStrategy> _Nullable (^)(id))defaultSerializerProvider __attribute__((swift_name("polymorphicDefaultSerializer(baseClass:defaultSerializerProvider:)")));
@end

__attribute__((swift_name("KotlinKDeclarationContainer")))
@protocol SharedKotlinKDeclarationContainer
@required
@end

__attribute__((swift_name("KotlinKAnnotatedElement")))
@protocol SharedKotlinKAnnotatedElement
@required
@end


/**
 * @note annotations
 *   kotlin.SinceKotlin(version="1.1")
*/
__attribute__((swift_name("KotlinKClassifier")))
@protocol SharedKotlinKClassifier
@required
@end

__attribute__((swift_name("KotlinKClass")))
@protocol SharedKotlinKClass <SharedKotlinKDeclarationContainer, SharedKotlinKAnnotatedElement, SharedKotlinKClassifier>
@required

/**
 * @note annotations
 *   kotlin.SinceKotlin(version="1.1")
*/
- (BOOL)isInstanceValue:(id _Nullable)value __attribute__((swift_name("isInstance(value:)")));
@property (readonly) NSString * _Nullable qualifiedName __attribute__((swift_name("qualifiedName")));
@property (readonly) NSString * _Nullable simpleName __attribute__((swift_name("simpleName")));
@end

#pragma pop_macro("_Nullable_result")
#pragma clang diagnostic pop
NS_ASSUME_NONNULL_END
